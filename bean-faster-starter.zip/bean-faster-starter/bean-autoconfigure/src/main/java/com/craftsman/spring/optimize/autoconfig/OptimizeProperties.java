package com.craftsman.spring.optimize.autoconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.ArrayList;
import java.util.List;


@ConfigurationProperties(prefix = "spring.accelerate")
public class OptimizeProperties {

    private List<String> asyncBeanPatterns=new ArrayList<String>();

    public List<String> getAsyncBeanPatterns(){
        return this.asyncBeanPatterns;
    }

    public void setAsyncBeanPatterns(List<String> asyncBeanPatterns){
        this.asyncBeanPatterns=asyncBeanPatterns;
    }

}
