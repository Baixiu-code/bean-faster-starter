package com.craftsman.spring.optimize.autoconfig;

import com.craftsman.spring.optimize.config.OptimizeAutoConfiguration;
import com.craftsman.spring.optimize.endpoint.BeanInitEndpoint;
import com.craftsman.spring.optimize.endpoint.BeanInitMetrics;
import com.craftsman.spring.optimize.listeners.BeanInitListener;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.bind.PropertySourcesPropertyValues;
import org.springframework.boot.bind.RelaxedDataBinder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySources;

import java.util.List;

/**
 * 用以读取spring 配置中 spring.accelerate.enabled 和 spring.accelerate的值。两个值的作用分别为
 * spring.accelerate=bean1|bean2 配置用以异步加速的bean的name
 * spring.accelerate.enabled =false 标识不启用异步加速
 */
@Configuration
@ConditionalOnProperty(name={"spring.accelerate.enabled"},havingValue = "true",matchIfMissing = true)
@EnableConfigurationProperties({OptimizeProperties.class})
public class OptimizeAutoConfig implements EnvironmentAware {

    private ConfigurableEnvironment environment;

    private OptimizeProperties optimizeProperties;

    @Bean(name = "beanInitMetric")
    public BeanInitMetrics beanInitMetrics(){
        return new BeanInitMetrics();
    }

    @Bean(name="beanInitEndpoint")
    public BeanInitEndpoint beanInitEndpoint(@Qualifier("beanInitMetric") BeanInitMetrics beanInitMetrics){
        return new BeanInitEndpoint(beanInitMetrics);
    }

    @Bean(name="beanInitListener")
    public BeanInitListener beanInitListener(@Qualifier("beanInitEndpoint")BeanInitEndpoint beanInitEndpoint){
        return new BeanInitListener(beanInitEndpoint);
    }
    @Override
    public void setEnvironment(Environment environment) {
        this.environment= (ConfigurableEnvironment) environment;
        resolveProperties();
        updateConfig();
    }

    private void updateConfig() {
        List<String> beanPatterns=this.optimizeProperties.getAsyncBeanPatterns();
        if(beanPatterns!=null && !beanPatterns.isEmpty()){
            OptimizeAutoConfiguration.CONFIG.setBeanPatterns(beanPatterns.<String>toArray(new String[beanPatterns.size()]));
        }
    }

    private void resolveProperties() {
        if(this.optimizeProperties!=null){
            return;
        }
        this.optimizeProperties=new OptimizeProperties();
        MutablePropertySources propertySources=this.environment.getPropertySources();
        (new RelaxedDataBinder(this.optimizeProperties,"spring.accelerate"))
                .bind((PropertyValues) new PropertySourcesPropertyValues((PropertySources) propertySources));
    }

}
