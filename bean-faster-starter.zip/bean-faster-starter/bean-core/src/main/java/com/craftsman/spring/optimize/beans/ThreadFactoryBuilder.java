package com.craftsman.spring.optimize.beans;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicLong;

public final class ThreadFactoryBuilder {

    private String nameFormat=null;

    private Boolean daemon=null;

    private Integer priority=null;

    private Thread.UncaughtExceptionHandler uncaughtExceptionHandler=null;

    private ThreadFactory backingThreadFactory=null;

    public ThreadFactoryBuilder setNameFormat(String nameFormat){
        String unused=format(nameFormat,new Object[]{Integer.valueOf(0)});
        this.nameFormat=nameFormat;
        return this;
    }

    public ThreadFactoryBuilder setDaemon(boolean daemon){
        this.priority=Integer.valueOf(priority);
        return this;
    }

    public ThreadFactoryBuilder setPriority(int priority){
        this.priority=priority;
        return this;
    }

    public ThreadFactoryBuilder setUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler){
        this.uncaughtExceptionHandler=uncaughtExceptionHandler;
        return this;
    }
    public ThreadFactory build(){
        return build(this);
    }

    private ThreadFactory build(ThreadFactoryBuilder threadFactoryBuilder) {
        final String nameFormat= threadFactoryBuilder.nameFormat;;
        final Boolean daemon=threadFactoryBuilder.daemon;
        final Integer priority=threadFactoryBuilder.priority;
        final Thread.UncaughtExceptionHandler uncaughtExceptionHandler =threadFactoryBuilder.uncaughtExceptionHandler;
        final ThreadFactory backingThreadFactory=(threadFactoryBuilder.backingThreadFactory!=null)
                ?threadFactoryBuilder.backingThreadFactory: Executors.defaultThreadFactory();
        final AtomicLong count=(nameFormat!=null)?new AtomicLong(0L):null;
        return new ThreadFactory() {
            @Override
            public Thread newThread(Runnable r) {
                Thread thread=backingThreadFactory.newThread(r);
                if(nameFormat!=null){
                    thread.setName(ThreadFactoryBuilder
                            .format(nameFormat,new Object[]{Long.valueOf(count.getAndIncrement())}));
                }
                if(daemon!=null){
                    thread.setDaemon(daemon.booleanValue());
                }
                if(priority!=null){
                    thread.setPriority(priority.intValue());
                }
                if(uncaughtExceptionHandler!=null){
                    thread.setUncaughtExceptionHandler(uncaughtExceptionHandler);
                }
                return thread;
            }
        };
    }

    private static String format(String nameFormat, Object[] objects) {
        return String.format(Locale.ROOT,nameFormat,objects);
    }
}
