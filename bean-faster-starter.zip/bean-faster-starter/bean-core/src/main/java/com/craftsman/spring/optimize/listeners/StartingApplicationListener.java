package com.craftsman.spring.optimize.listeners;

import com.craftsman.spring.optimize.beans.AsyncInitBeanFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.Ordered;
import java.lang.reflect.Field;

public class StartingApplicationListener{

    public static void attach(GenericApplicationContext context){
        AsyncInitBeanFactory beanFactory=new AsyncInitBeanFactory((BeanFactory)context.getBeanFactory(),16);
        try {
            Field field=GenericApplicationContext.class.getDeclaredField("beanFactory");
            field.setAccessible(true);
            field.set(context,beanFactory);
            context.addApplicationListener(new EventPublisher(beanFactory));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static class EventPublisher implements ApplicationListener<ContextRefreshedEvent>, Ordered {

        private final AsyncInitBeanFactory asyncInitBeanFactory;

        private EventPublisher(AsyncInitBeanFactory asyncInitBeanFactory) {
            this.asyncInitBeanFactory=asyncInitBeanFactory;
        }


        @Override
        public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
            if(this.asyncInitBeanFactory!=null){
                this.asyncInitBeanFactory.markInitAndWait();
            }
        }

        @Override
        public int getOrder() {
            return Integer.MIN_VALUE;
        }
    }
}
