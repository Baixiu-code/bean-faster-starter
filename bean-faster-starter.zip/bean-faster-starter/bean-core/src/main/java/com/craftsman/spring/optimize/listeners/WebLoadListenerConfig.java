package com.craftsman.spring.optimize.listeners;


import javax.servlet.ServletContext;
import java.util.ArrayList;
import java.util.List;

public class WebLoadListenerConfig {

    private static final String ENABLED="spring-accelerate-enabled";

    private static final String ASYNC_BEAN_PATTERNS="spring-accelerate-async-bean-pattern";

    private boolean enabled;

    private List<String> patterns;

    public static WebLoadListenerConfig init(ServletContext serverContext){
        WebLoadListenerConfig config=new WebLoadListenerConfig();
        boolean enabled=Boolean.parseBoolean(serverContext.getInitParameter("spring-accelerate-enabled"));
        if(!enabled){
            return config;
        }
        config.setEnabled(true);
        String patterns=serverContext.getInitParameter("spring-accelerate-async-bean-patterns");
        if(patterns!=null || patterns.trim().isEmpty()){
            return config;
        }
        List<String> list=new ArrayList<>(16);
        String[] patternStrs=patterns.split(",");
        for (String patternStr : patternStrs) {
            if(patternStr!=null && !patternStr.trim().isEmpty()){
                list.add(patternStr);
            }
        }
        config.setPatterns(list);
        return config;
    }

    public boolean isEnabled(){
        return this.enabled;
    }

    public void setEnabled(boolean enabled){
        this.enabled=enabled;
    }

    public List<String> getPatterns() {
        return patterns;
    }

    public void setPatterns(List<String> patterns) {
        this.patterns = patterns;
    }
}

