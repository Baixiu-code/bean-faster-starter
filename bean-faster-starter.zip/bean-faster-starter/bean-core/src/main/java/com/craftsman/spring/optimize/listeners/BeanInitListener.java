package com.craftsman.spring.optimize.listeners;

import com.craftsman.spring.optimize.endpoint.BeanInitEndpoint;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.util.FileCopyUtils;

import java.io.*;

/**
 * spring boot 项目后 启动后 开始监听 并写入至log文件
 */
public class BeanInitListener implements ApplicationListener<ContextRefreshedEvent> {

    private final BeanInitEndpoint beanInitEndpoint;

    public BeanInitListener(BeanInitEndpoint beanInitEndpoint) {
        this.beanInitEndpoint = beanInitEndpoint;
    }


    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        try {
            write(String.valueOf(this.beanInitEndpoint.invoke()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void write(String text) throws IOException {
        FileOutputStream os=null;
        try {
            os=new FileOutputStream(getLogFile());
            FileCopyUtils.copy(text,new OutputStreamWriter(os,"utf-8"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }finally {
            if(os!=null){
                try {
                    os.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static File getLogFile() {
        File file=new File(getLogPath());
        if(!file.getParentFile().exists()){
            file.getParentFile().mkdir();
        }
        return file;
    }

    private static String getLogPath() {
        StringBuffer stringBuffer=new StringBuffer();
        stringBuffer.append(System.getProperty("user.home"));
        stringBuffer.append("/");
        String projectName= System.getProperty("project.name");
        if(projectName==null || projectName.trim().isEmpty()){
            stringBuffer.append("logs/");
        }else{
            stringBuffer.append(projectName).append("/logs/");
        }
        stringBuffer.append("bean-init-optimized.log");
        return stringBuffer.toString();
    }
}
