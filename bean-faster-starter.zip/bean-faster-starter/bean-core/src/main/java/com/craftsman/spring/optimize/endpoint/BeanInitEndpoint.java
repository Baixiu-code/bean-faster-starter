package com.craftsman.spring.optimize.endpoint;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.actuate.endpoint.Endpoint;
import org.springframework.boot.actuate.metrics.Metric;
import java.text.SimpleDateFormat;
import java.util.Collection;


/**
 * 利用 springboot actuate endpoint 能力 追踪bean 启动时间并记录可供异步初始化bean的信息
 */
public class BeanInitEndpoint implements Endpoint {

    private final BeanInitMetrics beanInitMetrics;

    public BeanInitEndpoint(BeanInitMetrics beanInitMetrics) {
        this.beanInitMetrics = beanInitMetrics;
    }

    @Override
    public String getId() {
        return "bean-init";
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public boolean isSensitive() {
        return false;
    }

    @Override
    public Object invoke() {
        return prettyPrint(this.beanInitMetrics.metrics());
    }

    private String prettyPrint(Collection<Metric<?>> metricCollection){
        ObjectMapper mapper=new ObjectMapper();
        mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(metricCollection);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return  "error"+e.getMessage();
        }
    }
}
