package com.craftsman.spring.optimize.listeners;

import com.craftsman.spring.optimize.config.OptimizeAutoConfiguration;
import com.craftsman.spring.optimize.context.WebOptimizeStartingInitializer;
import org.springframework.web.context.ContextLoaderListener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

public class StartingWebLoadListener extends ContextLoaderListener {

    private WebLoadListenerConfig config;

    @Override
    public void contextInitialized(ServletContextEvent event) {
        this.config=WebLoadListenerConfig.init(event.getServletContext());
        if(this.config.isEnabled() && this.config.getPatterns()!=null){
            OptimizeAutoConfiguration.CONFIG.setBeanPatterns(this.config.getPatterns()
                    .toArray(new String[this.config.getPatterns().size()]));
            super.contextInitialized(event);
        }
    }

    @Override
    protected Class<?> determineContextClass(ServletContext servletContext) {
        if(this.config.isEnabled()){
            return WebOptimizeStartingInitializer.class;
        }
        return super.determineContextClass(servletContext);
    }
}
