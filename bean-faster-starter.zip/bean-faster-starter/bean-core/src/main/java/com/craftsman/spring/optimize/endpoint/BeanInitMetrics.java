package com.craftsman.spring.optimize.endpoint;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.AbstractBeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.boot.actuate.endpoint.PublicMetrics;
import org.springframework.boot.actuate.metrics.Metric;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 用以获取可以进行异步初始化的bean对象数组
 */
public class BeanInitMetrics implements BeanPostProcessor, PublicMetrics, ApplicationContextAware {

    /**
     * 保存bean的名称以及启动的时间(毫秒)
     */
    private final Map<String,Long> stats=new ConcurrentHashMap<String,Long>(16);

    private final Map<String,Metric<Long>> metrics=new HashMap<>(16);

    private DefaultListableBeanFactory beanFactory;

    private Method getRootBeanDefinition;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        ConfigurableApplicationContext context= (ConfigurableApplicationContext) applicationContext;
        String methodName="getMergedLocalBeanDefinition";
        this.beanFactory= (DefaultListableBeanFactory) context.getBeanFactory();
        this.getRootBeanDefinition= ReflectionUtils.findMethod(AbstractBeanFactory.class,methodName,new Class[]{String.class});
        this.getRootBeanDefinition.setAccessible(true);
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        this.stats.put(beanName,Long.valueOf(System.currentTimeMillis()));
        return bean;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Long stat=this.stats.get(beanName);
        if(stat!=null){
            String name=hasInitMethod(bean,beanName)?(beanName+"(Init can be optimized)"):beanName;
            this.metrics.put(beanName,new Metric(name,Long.valueOf(System.currentTimeMillis()-stat.longValue())));
        }
        try {
            this.stats.remove(beanName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bean;
    }

    @Override
    public Collection<Metric<?>> metrics() {
        List<Metric<?>> list=new ArrayList<Metric<?>>(this.metrics.values());
        Collections.sort(list, (o1, o2) -> {
            long diff=o1.getValue().longValue()-o2.getValue().longValue();
            if(diff>0){
                return -1;
            }else if(diff<0){
                return 1;
            }
            return 0;
        });
        return Collections.unmodifiableCollection(list);
    }



    /**
     * bean是否含有init method
     * @param bean
     * @param beanName
     * @return
     */
    private boolean hasInitMethod(Object bean,String beanName){
        RootBeanDefinition rootBeanDefinition=null;
        try {
            rootBeanDefinition=getRootBeanDefinition(beanName);
        } catch (Exception e) {

        }
        boolean isInitBean= bean instanceof InitializingBean;
        if(isInitBean && (rootBeanDefinition ==null || !rootBeanDefinition.isExternallyManagedInitMethod("afterPropertiesSet"))){
            return true;
        }
        if(rootBeanDefinition ==null){
            return false;
        }
        String initMethodName=rootBeanDefinition.getInitMethodName();
        if(initMethodName==null || (isInitBean && "afterPropertiesSet".equals(initMethodName))
                || rootBeanDefinition.isExternallyManagedInitMethod(initMethodName)){
            return false;
        }
        Method initMethod=rootBeanDefinition.isNonPublicAccessAllowed() ?
                BeanUtils.findMethod(bean.getClass(),initMethodName,new Class[0])
                : ClassUtils.getMethodIfAvailable(bean.getClass(),initMethodName,new Class[0]);
        return initMethod!=null;
    }

    private RootBeanDefinition getRootBeanDefinition(String beanName){
        return (RootBeanDefinition)ReflectionUtils.invokeMethod(this.getRootBeanDefinition,this.beanFactory,new Object[]{beanName});
    }

}
