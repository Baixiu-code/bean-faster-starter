package com.craftsman.spring.optimize.context;

import com.craftsman.spring.optimize.beans.AsyncInitBeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.web.context.support.XmlWebApplicationContext;

public class WebOptimizeStartingInitializer extends XmlWebApplicationContext {

    private AsyncInitBeanFactory asyncInitBeanFactory;

    @Override
    protected DefaultListableBeanFactory createBeanFactory() {
        this.asyncInitBeanFactory=new AsyncInitBeanFactory(super.getBeanFactory(),16);
        return this.asyncInitBeanFactory;
    }

    protected void finishRefresh(){
        if(this.asyncInitBeanFactory!=null){
            this.asyncInitBeanFactory.markInitAndWait();

        }
        super.finishRefresh();
    }
}
