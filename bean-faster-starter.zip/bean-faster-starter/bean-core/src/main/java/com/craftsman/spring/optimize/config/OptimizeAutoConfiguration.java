package com.craftsman.spring.optimize.config;

import java.util.regex.Pattern;

public class OptimizeAutoConfiguration {

    public static final OptimizeAutoConfiguration CONFIG=new OptimizeAutoConfiguration();

    private Pattern[] beanPatterns;

    public void setBeanPatterns(String[] patterns){
        if(patterns==null){
            this.beanPatterns=null;
            return;
        }
        this.beanPatterns=new Pattern[patterns.length];
        for (int i = 0; i < patterns.length; i++) {
            this.beanPatterns[i]=Pattern.compile(patterns[i]);
        }

    }

    public boolean async(String beanName){
        if(this.beanPatterns==null || this.beanPatterns.length<1){
            return false;
        }
        for (int i = 0; i < beanPatterns.length; i++) {
            if(beanPatterns[i].matcher(beanName).matches()){
                return true;
            }
        }
        return false;
    }
}


