package com.craftsman.spring.optimize.beans;

import com.craftsman.spring.optimize.config.OptimizeAutoConfiguration;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.RootBeanDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class AsyncInitBeanFactory extends DefaultListableBeanFactory {

    private final ThreadPoolExecutor threadPoolExecutor;

    private static final List<Future> FUTURES=new ArrayList<>(16);

    public AsyncInitBeanFactory(BeanFactory beanFactory,Integer poolSize) {
        super(beanFactory);
        this.threadPoolExecutor=new ThreadPoolExecutor(poolSize, poolSize, 5L
                , TimeUnit.SECONDS, new LinkedBlockingDeque<>(), getThreadFactory(),new ThreadPoolExecutor.AbortPolicy());
    }

    public void markInitAndWait() {
        for(Future futures:FUTURES){
            try {
                futures.get();
            } catch (Exception e) {
                shutDown();
                throw new RuntimeException(e);
            }
        }
    }

    protected void invokeInitMethods(String beanName, Object bean, RootBeanDefinition rootBeanDefinition)throws Throwable{
        if(!OptimizeAutoConfiguration.CONFIG.async(beanName)){
            super.invokeInitMethods(beanName,bean,rootBeanDefinition);
        }else{
            final String fBeanName=beanName;
            final Object fBean=bean;
            final RootBeanDefinition fRootBeanDefinition=rootBeanDefinition;
            FUTURES.add(this.threadPoolExecutor.submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        AsyncInitBeanFactory.this.invokeInitMethods(fBeanName,fBean,fRootBeanDefinition);
                    } catch (Throwable throwable) {
                        throwable.printStackTrace();
                    }
                }
            }));
        }
    }



    private void shutDown() {
        if(this.threadPoolExecutor!=null){
            try {
                this.threadPoolExecutor.shutdown();
            } catch (Exception e) {

            }
        }
    }

    private ThreadFactory getThreadFactory(){
        return (new ThreadFactoryBuilder()).setNameFormat("spring-accelerate-starting-%d").build();
    }
}
