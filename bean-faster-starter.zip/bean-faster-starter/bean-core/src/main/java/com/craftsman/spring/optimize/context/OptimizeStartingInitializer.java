package com.craftsman.spring.optimize.context;

import com.craftsman.spring.optimize.listeners.StartingApplicationListener;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.Ordered;

public class OptimizeStartingInitializer implements ApplicationContextInitializer<ConfigurableApplicationContext>,Ordered {

    @Override
    public void initialize(ConfigurableApplicationContext configurableApplicationContext) {
        if(configurableApplicationContext instanceof GenericApplicationContext){
            StartingApplicationListener.attach((GenericApplicationContext) configurableApplicationContext);
        }
    }

    @Override
    public int getOrder() {
        return Integer.MAX_VALUE;
    }
}
