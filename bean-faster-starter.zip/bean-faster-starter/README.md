# bean-faster-starter
for decrease container start time
